TODO:
1 - Move ingress to different ns
2 - For agents - use karpenter.sh/do-not-disrupt
3 - Update resource quotas for Agents and for Server
4 - Review CMs
5 - TLS via code
6 - fix hardcoded stuff